# Production checklist

- Add final app icon/logo.
- Add login/authentication.
- Move the free-Reel counter to the backend.
- Connect a real AI video-generation provider.
- Use an async job system: queued -> processing -> completed/failed.
- Store generated videos in cloud storage.
- Add moderation and abuse protection.
- Create `premium_monthly` in Google Play Console.
- Verify and acknowledge purchases on the backend.
- Handle renewal, cancellation, expiration and refund/revocation.
- Create your AdMob app and banner unit.
- Replace AdMob test IDs only for release.
- Add Privacy Policy, Terms and account deletion where applicable.
- Build a signed Android App Bundle (.aab).
