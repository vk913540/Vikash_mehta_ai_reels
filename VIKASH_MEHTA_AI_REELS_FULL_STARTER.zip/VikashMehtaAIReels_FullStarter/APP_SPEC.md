# VIKASH MEHTA AI REELS

Brand: VIKASH MEHTA 8051
Free allowance: 1 Reel
Premium example: ₹99/month
Free users: bottom banner ad
Premium users: ad-free

Screens:
Splash -> Login -> Home/Create -> Prompt/Media -> Generation -> Result/Share
                                      -> Premium Paywall
Settings -> Subscription management / Privacy / Terms

Architecture:
Android -> HTTPS backend -> AI video provider + database + storage
Android -> Google Play Billing
Android -> AdMob for free users

This package is a full starter/architecture. A deployed commercial AI service still requires your provider, Google Play, AdMob and hosting accounts.
