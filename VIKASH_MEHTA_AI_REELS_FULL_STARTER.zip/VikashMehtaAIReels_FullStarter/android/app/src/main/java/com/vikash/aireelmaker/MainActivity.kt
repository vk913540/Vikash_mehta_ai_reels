package com.vikash.aireelmaker

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.android.billingclient.api.*

class MainActivity : ComponentActivity() {
    private lateinit var billingClient: BillingClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}

        billingClient = BillingClient.newBuilder(this)
            .setListener { result, purchases ->
                if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
                    Toast.makeText(this, "Purchase received. Verify on your backend before granting premium.", Toast.LENGTH_LONG).show()
                }
            }
            .enablePendingPurchases()
            .build()

        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {}
            override fun onBillingServiceDisconnected() {}
        })

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF8AB4F8),
                    background = Color(0xFF101114),
                    surface = Color(0xFF181A1F)
                )
            ) {
                ReelMakerScreen()
            }
        }
    }

    fun buyPremium() {
        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(
                listOf(
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId("premium_monthly")
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build()
                )
            ).build()

        billingClient.queryProductDetailsAsync(params) { result, details ->
            val product = details.firstOrNull()
            val offer = product?.subscriptionOfferDetails?.firstOrNull()
            val token = offer?.offerToken
            if (result.responseCode == BillingClient.BillingResponseCode.OK &&
                product != null && token != null) {
                val flowParams = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(
                        listOf(
                            BillingFlowParams.ProductDetailsParams.newBuilder()
                                .setProductDetails(product)
                                .setOfferToken(token)
                                .build()
                        )
                    ).build()
                billingClient.launchBillingFlow(this, flowParams)
            } else {
                Toast.makeText(this, "Create premium_monthly in Play Console first.", Toast.LENGTH_LONG).show()
            }
        }
    }
}

@Composable
fun ReelMakerScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("reel_prefs", 0) }
    var usedFreeReel by remember { mutableStateOf(prefs.getBoolean("used_free_reel", false)) }
    var premium by remember { mutableStateOf(false) }
    var prompt by remember { mutableStateOf("") }
    var generating by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = {
            if (!premium) {
                AndroidBannerAd()
            }
        },
        containerColor = Color(0xFF101114)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "VIKASH MEHTA AI REELS",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Create AI reels with VIKASH MEHTA 8051.",
                color = Color.LightGray
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1D22)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Your Reel", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 4,
                        placeholder = { Text("Example: cinematic motivational reel about success") }
                    )

                    Button(
                        onClick = {
                            if (!premium && usedFreeReel) {
                                Toast.makeText(context, "Your free Reel is already used. Please subscribe.", Toast.LENGTH_LONG).show()
                            } else {
                                generating = true
                                // Prototype: replace this with your AI video API/backend.
                                android.os.Handler(mainLooper).postDelayed({
                                    generating = false
                                    if (!premium) {
                                        usedFreeReel = true
                                        prefs.edit().putBoolean("used_free_reel", true).apply()
                                    }
                                    Toast.makeText(context, "Demo Reel generated. Connect an AI video API for real generation.", Toast.LENGTH_LONG).show()
                                }, 1200)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !generating && prompt.isNotBlank()
                    ) {
                        Icon(Icons.Default.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (generating) "Generating..." else "CREATE REEL")
                    }
                }
            }

            if (!premium && usedFreeReel) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF20242B)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.Lock, null)
                        Text("Free Reel used", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Subscribe to unlock more AI Reel generations and remove ads.")
                        Button(
                            onClick = { (context as? MainActivity)?.buyPremium() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.WorkspacePremium, null)
                            Spacer(Modifier.width(8.dp))
                            Text("GET PREMIUM")
                        }
                    }
                }
            }

            if (premium) {
                AssistChip(
                    onClick = {},
                    label = { Text("Premium Active") },
                    leadingIcon = { Icon(Icons.Default.WorkspacePremium, null) }
                )
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF181A1F)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Premium plan", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Example: ₹99/month")
                    Text("• More Reel generations")
                    Text("• Premium templates")
                    Text("• No banner ads")
                    Text("• Faster generation")
                }
            }
        }
    }
}

@Composable
fun AndroidBannerAd() {
    AndroidView(
        factory = { context ->
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                // Google test banner ID. Replace with your AdMob unit ID before release.
                adUnitId = "ca-app-pub-3940256099942544/9214589741"
                loadAd(AdRequest.Builder().build())
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .background(Color(0xFF101114))
    )
}
